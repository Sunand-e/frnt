export const DIGITS: string[] = [
  '1',
  '2',
  '3',
  '4',
  '5',
  '6',
  '7',
  '8',
  '9',
  '0',
];

export const DIGITS_WITH_SPACE: string[] = DIGITS.map((digit) => ` ${digit}`);
